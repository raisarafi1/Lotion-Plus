# add your delete-note function here
import boto3

def lambda_handler(event, context):
    # Create a DynamoDB resource
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('table_name')

    # try:
        # Delete the item from the table
    response = table.delete_item(
        Key={
            'partition_key_name': 'partition_key_value',
            'sort_key_name': 'sort_key_value'
        }
    )
    print(response)
    # except Exception as e:
        # print(e)
